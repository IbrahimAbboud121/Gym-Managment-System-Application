﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GymManagment.Model
{
    public class TrainersModel
    {
     
         public string TrainerId { get; set; }
        public string Name { get; set; }
        public string Specialization { get; set; }
        public string AssignedClasses { get; set; }

        public TrainersModel(string id,string name,string special,string classes)
        {
            TrainerId = id;
            Name = name;
            Specialization = special;
            AssignedClasses = classes;
        }
        public override string ToString()
        {
            return $"Id:{TrainerId},Name:{Name},Specialization:{Specialization},Assigned Classes:{AssignedClasses}";
        }

    }
}
