﻿namespace GymManagment
{
    partial class ClassSessionsMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ClassSessionsMenu));
            label1 = new Label();
            label2 = new Label();
            label4 = new Label();
            button1 = new Button();
            IdBox = new Krypton.Toolkit.KryptonTextBox();
            NameBox = new Krypton.Toolkit.KryptonTextBox();
            DateTimeBox = new DateTimePicker();
            button2 = new Button();
            DataGridViewTrainers = new DataGridView();
            Trainer = new DataGridViewTextBoxColumn();
            Class = new DataGridViewTextBoxColumn();
            ScheduleTime = new DataGridViewTextBoxColumn();
            SlotsAvailable = new DataGridViewTextBoxColumn();
            refresh = new Button();
            DataGridViewMembers = new DataGridView();
            dataGridViewTextBoxColumn1 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn2 = new DataGridViewTextBoxColumn();
            addMembers = new Krypton.Toolkit.KryptonTextBox();
            OldMember = new Label();
            AddOldMember = new Button();
            ((System.ComponentModel.ISupportInitialize)DataGridViewTrainers).BeginInit();
            ((System.ComponentModel.ISupportInitialize)DataGridViewMembers).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(231, 157);
            label1.Name = "label1";
            label1.Size = new Size(95, 25);
            label1.TabIndex = 11;
            label1.Text = "Session ID";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(404, 157);
            label2.Name = "label2";
            label2.Size = new Size(104, 25);
            label2.TabIndex = 12;
            label2.Text = "Class Name";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(577, 157);
            label4.Name = "label4";
            label4.Size = new Size(119, 25);
            label4.TabIndex = 14;
            label4.Text = "scheduleTime";
            // 
            // button1
            // 
            button1.Location = new Point(303, 396);
            button1.Name = "button1";
            button1.Size = new Size(96, 31);
            button1.TabIndex = 17;
            button1.Text = "Back";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // IdBox
            // 
            IdBox.Location = new Point(230, 185);
            IdBox.Name = "IdBox";
            IdBox.Size = new Size(96, 31);
            IdBox.TabIndex = 18;
            // 
            // NameBox
            // 
            NameBox.Location = new Point(404, 185);
            NameBox.Name = "NameBox";
            NameBox.Size = new Size(96, 31);
            NameBox.TabIndex = 19;
            NameBox.TextChanged += kryptonTextBox1_TextChanged;
            // 
            // DateTimeBox
            // 
            DateTimeBox.Location = new Point(577, 185);
            DateTimeBox.Name = "DateTimeBox";
            DateTimeBox.Size = new Size(102, 31);
            DateTimeBox.TabIndex = 21;
            // 
            // button2
            // 
            button2.Location = new Point(697, 396);
            button2.Name = "button2";
            button2.Size = new Size(96, 31);
            button2.TabIndex = 24;
            button2.Text = "Add";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // DataGridViewTrainers
            // 
            DataGridViewTrainers.AllowUserToAddRows = false;
            DataGridViewTrainers.AllowUserToDeleteRows = false;
            DataGridViewTrainers.AllowUserToResizeColumns = false;
            DataGridViewTrainers.AllowUserToResizeRows = false;
            DataGridViewTrainers.BackgroundColor = SystemColors.ButtonHighlight;
            DataGridViewTrainers.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DataGridViewTrainers.Columns.AddRange(new DataGridViewColumn[] { Trainer, Class, ScheduleTime, SlotsAvailable });
            DataGridViewTrainers.Location = new Point(560, 242);
            DataGridViewTrainers.Name = "DataGridViewTrainers";
            DataGridViewTrainers.ReadOnly = true;
            DataGridViewTrainers.RowHeadersVisible = false;
            DataGridViewTrainers.RowHeadersWidth = 62;
            DataGridViewTrainers.Size = new Size(303, 135);
            DataGridViewTrainers.TabIndex = 26;
            DataGridViewTrainers.CellContentClick += DataGridView_CellContentClick;
            // 
            // Trainer
            // 
            Trainer.HeaderText = "Trainer";
            Trainer.MinimumWidth = 8;
            Trainer.Name = "Trainer";
            Trainer.ReadOnly = true;
            Trainer.Resizable = DataGridViewTriState.True;
            Trainer.Width = 150;
            // 
            // Class
            // 
            Class.HeaderText = "ClassSession";
            Class.MinimumWidth = 8;
            Class.Name = "Class";
            Class.ReadOnly = true;
            Class.Width = 150;
            // 
            // ScheduleTime
            // 
            ScheduleTime.HeaderText = "ScheduleTime";
            ScheduleTime.MinimumWidth = 8;
            ScheduleTime.Name = "ScheduleTime";
            ScheduleTime.ReadOnly = true;
            ScheduleTime.Width = 150;
            // 
            // SlotsAvailable
            // 
            SlotsAvailable.HeaderText = "SlotsAvailable";
            SlotsAvailable.MinimumWidth = 8;
            SlotsAvailable.Name = "SlotsAvailable";
            SlotsAvailable.ReadOnly = true;
            SlotsAvailable.Width = 150;
            // 
            // refresh
            // 
            refresh.Location = new Point(504, 464);
            refresh.Name = "refresh";
            refresh.Size = new Size(96, 31);
            refresh.TabIndex = 28;
            refresh.Text = "Refresh";
            refresh.UseVisualStyleBackColor = true;
            refresh.Click += refresh_Click;
            // 
            // DataGridViewMembers
            // 
            DataGridViewMembers.AllowUserToAddRows = false;
            DataGridViewMembers.AllowUserToDeleteRows = false;
            DataGridViewMembers.AllowUserToResizeColumns = false;
            DataGridViewMembers.AllowUserToResizeRows = false;
            DataGridViewMembers.BackgroundColor = SystemColors.ButtonHighlight;
            DataGridViewMembers.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DataGridViewMembers.Columns.AddRange(new DataGridViewColumn[] { dataGridViewTextBoxColumn1, dataGridViewTextBoxColumn2 });
            DataGridViewMembers.Location = new Point(230, 242);
            DataGridViewMembers.Name = "DataGridViewMembers";
            DataGridViewMembers.ReadOnly = true;
            DataGridViewMembers.RowHeadersVisible = false;
            DataGridViewMembers.RowHeadersWidth = 62;
            DataGridViewMembers.Size = new Size(290, 135);
            DataGridViewMembers.TabIndex = 29;
            // 
            // dataGridViewTextBoxColumn1
            // 
            dataGridViewTextBoxColumn1.HeaderText = "Member";
            dataGridViewTextBoxColumn1.MinimumWidth = 8;
            dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            dataGridViewTextBoxColumn1.ReadOnly = true;
            dataGridViewTextBoxColumn1.Resizable = DataGridViewTriState.True;
            dataGridViewTextBoxColumn1.Width = 150;
            // 
            // dataGridViewTextBoxColumn2
            // 
            dataGridViewTextBoxColumn2.HeaderText = "Sessions";
            dataGridViewTextBoxColumn2.MinimumWidth = 8;
            dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            dataGridViewTextBoxColumn2.ReadOnly = true;
            dataGridViewTextBoxColumn2.Width = 150;
            // 
            // addMembers
            // 
            addMembers.Location = new Point(767, 185);
            addMembers.Name = "addMembers";
            addMembers.Size = new Size(96, 31);
            addMembers.TabIndex = 30;
            addMembers.TextChanged += AddMembers_TextChanged;
            // 
            // OldMember
            // 
            OldMember.AutoSize = true;
            OldMember.Location = new Point(767, 157);
            OldMember.Name = "OldMember";
            OldMember.Size = new Size(113, 25);
            OldMember.TabIndex = 31;
            OldMember.Text = "AddMember";
            // 
            // AddOldMember
            // 
            AddOldMember.Location = new Point(869, 185);
            AddOldMember.Name = "AddOldMember";
            AddOldMember.Size = new Size(96, 31);
            AddOldMember.TabIndex = 32;
            AddOldMember.Text = "Add";
            AddOldMember.UseVisualStyleBackColor = true;
            AddOldMember.Click += AddOldMember_Click;
            // 
            // ClassSessionsMenu
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(1042, 597);
            Controls.Add(AddOldMember);
            Controls.Add(OldMember);
            Controls.Add(addMembers);
            Controls.Add(DataGridViewMembers);
            Controls.Add(refresh);
            Controls.Add(DataGridViewTrainers);
            Controls.Add(button2);
            Controls.Add(DateTimeBox);
            Controls.Add(NameBox);
            Controls.Add(IdBox);
            Controls.Add(button1);
            Controls.Add(label4);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "ClassSessionsMenu";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "ClassSessionsMenu";
            ((System.ComponentModel.ISupportInitialize)DataGridViewTrainers).EndInit();
            ((System.ComponentModel.ISupportInitialize)DataGridViewMembers).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label4;
        private Button button1;
        private Krypton.Toolkit.KryptonTextBox IdBox;
        private Krypton.Toolkit.KryptonTextBox NameBox;
        private DateTimePicker DateTimeBox;
        private Button button2;
        private DataGridView DataGridViewTrainers;
        private Button refresh;
        private DataGridViewTextBoxColumn Trainer;
        private DataGridViewTextBoxColumn Class;
        private DataGridViewTextBoxColumn ScheduleTime;
        private DataGridViewTextBoxColumn SlotsAvailable;
        private DataGridView DataGridViewMembers;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private Krypton.Toolkit.KryptonTextBox addMembers;
        private Label OldMember;
        private Button AddOldMember;
    }
}