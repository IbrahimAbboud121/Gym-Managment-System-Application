﻿using Microsoft.VisualBasic.Logging;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Windows.Forms;
using System.Windows.Forms;
using TheArtOfDev.HtmlRenderer.Adapters;
namespace GymManagment.Views
{
    
    public partial class Introduction : Form
    {
        private System.Windows.Forms.Timer timer;
        public Introduction()
        {
            InitializeComponent();
            timer = new System.Windows.Forms.Timer();
        }

        private void Introduction_Load(object sender, EventArgs e)
        {
            timer.Interval = 5000;
            timer.Tick += (s, args) =>
            {
                timer.Stop();
                this.Hide(); 
                Login login = new Login();
                login.Show();

            };
            timer.Start();
           
        }
    }
}
