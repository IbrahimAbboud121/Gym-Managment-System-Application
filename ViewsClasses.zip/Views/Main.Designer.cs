﻿namespace GymManagment
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            MembersButton = new Button();
            TrainersButton = new Button();
            ClassSessionsButton = new Button();
            SuspendLayout();
            // 
            // MembersButton
            // 
            MembersButton.FlatStyle = FlatStyle.Flat;
            MembersButton.Location = new Point(128, 210);
            MembersButton.Name = "MembersButton";
            MembersButton.Size = new Size(283, 95);
            MembersButton.TabIndex = 0;
            MembersButton.Text = "Members";
            MembersButton.UseVisualStyleBackColor = true;
            MembersButton.Click += button1_Click;
            // 
            // TrainersButton
            // 
            TrainersButton.Location = new Point(128, 490);
            TrainersButton.Name = "TrainersButton";
            TrainersButton.Size = new Size(283, 95);
            TrainersButton.TabIndex = 1;
            TrainersButton.Text = "Trainers";
            TrainersButton.UseVisualStyleBackColor = true;
            TrainersButton.Click += TrainersButton_Click;
            // 
            // ClassSessionsButton
            // 
            ClassSessionsButton.Location = new Point(128, 346);
            ClassSessionsButton.Name = "ClassSessionsButton";
            ClassSessionsButton.Size = new Size(283, 95);
            ClassSessionsButton.TabIndex = 2;
            ClassSessionsButton.Text = "ClassSessions";
            ClassSessionsButton.UseVisualStyleBackColor = true;
            ClassSessionsButton.Click += ClassSessionsButton_Click;
            // 
            // Main
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(534, 677);
            Controls.Add(ClassSessionsButton);
            Controls.Add(TrainersButton);
            Controls.Add(MembersButton);
            Name = "Main";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Main";
            Load += Main_Load;
            ResumeLayout(false);
        }

        #endregion

        private Button MembersButton;
        private Button TrainersButton;
        private Button ClassSessionsButton;
    }
}