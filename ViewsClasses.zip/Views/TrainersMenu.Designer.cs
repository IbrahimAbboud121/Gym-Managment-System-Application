﻿namespace GymManagment
{
    partial class TrainersMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TrainersMenu));
            IdBox = new Krypton.Toolkit.KryptonTextBox();
            NameBox = new Krypton.Toolkit.KryptonTextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            back = new Button();
            AssignedClassesBox = new TextBox();
            Add = new Button();
            remove = new Button();
            SpecializationBox = new TextBox();
            button1 = new Button();
            SuspendLayout();
            // 
            // IdBox
            // 
            IdBox.Location = new Point(310, 210);
            IdBox.Name = "IdBox";
            IdBox.Size = new Size(96, 31);
            IdBox.TabIndex = 5;
            // 
            // NameBox
            // 
            NameBox.Location = new Point(502, 210);
            NameBox.Name = "NameBox";
            NameBox.Size = new Size(96, 31);
            NameBox.TabIndex = 6;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(310, 182);
            label1.Name = "label1";
            label1.Size = new Size(86, 25);
            label1.TabIndex = 10;
            label1.Text = "Trainer ID";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(502, 182);
            label2.Name = "label2";
            label2.Size = new Size(59, 25);
            label2.TabIndex = 11;
            label2.Text = "Name";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(704, 182);
            label3.Name = "label3";
            label3.Size = new Size(117, 25);
            label3.TabIndex = 12;
            label3.Text = "specialization";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(369, 323);
            label4.Name = "label4";
            label4.Size = new Size(147, 25);
            label4.TabIndex = 13;
            label4.Text = "Assigned Classes";
            // 
            // back
            // 
            back.Location = new Point(399, 427);
            back.Name = "back";
            back.Size = new Size(96, 31);
            back.TabIndex = 14;
            back.Text = "Back";
            back.UseVisualStyleBackColor = true;
            back.Click += back_Click;
            // 
            // AssignedClassesBox
            // 
            AssignedClassesBox.AcceptsReturn = true;
            AssignedClassesBox.Location = new Point(369, 351);
            AssignedClassesBox.Multiline = true;
            AssignedClassesBox.Name = "AssignedClassesBox";
            AssignedClassesBox.ScrollBars = ScrollBars.Vertical;
            AssignedClassesBox.Size = new Size(126, 31);
            AssignedClassesBox.TabIndex = 15;
            AssignedClassesBox.TextChanged += textBox1_TextChanged;
            // 
            // Add
            // 
            Add.Location = new Point(579, 351);
            Add.Name = "Add";
            Add.Size = new Size(96, 31);
            Add.TabIndex = 16;
            Add.Text = "Add";
            Add.UseVisualStyleBackColor = true;
            Add.Click += button2_Click;
            // 
            // remove
            // 
            remove.Location = new Point(579, 427);
            remove.Name = "remove";
            remove.Size = new Size(96, 31);
            remove.TabIndex = 17;
            remove.Text = "Remove";
            remove.UseVisualStyleBackColor = true;
            remove.Click += remove_Click;
            // 
            // SpecializationBox
            // 
            SpecializationBox.AcceptsReturn = true;
            SpecializationBox.Location = new Point(704, 210);
            SpecializationBox.Multiline = true;
            SpecializationBox.Name = "SpecializationBox";
            SpecializationBox.ScrollBars = ScrollBars.Vertical;
            SpecializationBox.Size = new Size(126, 31);
            SpecializationBox.TabIndex = 18;
            // 
            // button1
            // 
            button1.Location = new Point(734, 351);
            button1.Name = "button1";
            button1.Size = new Size(96, 31);
            button1.TabIndex = 19;
            button1.Text = "Reset";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // TrainersMenu
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(1042, 597);
            Controls.Add(button1);
            Controls.Add(SpecializationBox);
            Controls.Add(remove);
            Controls.Add(Add);
            Controls.Add(AssignedClassesBox);
            Controls.Add(back);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(NameBox);
            Controls.Add(IdBox);
            Name = "TrainersMenu";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "TrainersMenu";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Krypton.Toolkit.KryptonTextBox IdBox;
        private Krypton.Toolkit.KryptonTextBox NameBox;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Button back;
        private TextBox AssignedClassesBox;
        private Button Add;
        private Button remove;
        private TextBox SpecializationBox;
        private Button button1;
    }
}