﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GymManagment.Model;
using GymManagment.Controller;

namespace GymManagment
{
    public partial class MembersMenu : Form
    {
        private MemberModel member;
        Dictionary<string, string> empty = [];
        MembersController control;
        public MembersMenu()
        {
            InitializeComponent();
            member = new MemberModel(IdBox.Text, NameBox.Text, MembershipBox.Text, StatusBox.Text, EnrolledClassesBox.Text);
            member = new MemberModel("", "", "", "", "");
            control = new MembersController();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void IdBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void AddButton_Click(object sender, EventArgs e)
        {
            member.MemberId = IdBox.Text;
            member.Name = NameBox.Text;
            member.MembershipType = MembershipBox.Text;
            member.ActiveStatus = StatusBox.Text;
            member.EnrolledClasses = EnrolledClassesBox.Text;
            empty.Add("MemberId",member.MemberId);
            empty.Add("Name", member.Name);
            empty.Add("Membership Type", member.MembershipType);
            empty.Add("Active status", member.ActiveStatus);
            empty.Add("Enrolled classes", member.EnrolledClasses);



            foreach (KeyValuePair<string, string> kvp in empty)
            {
                if (kvp.Value == "")
                {
                    MessageBox.Show($"{kvp.Key} cannot be empty", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    empty = [];
                    break;
                }
            }
            if ((member.MemberId != "" && member.Name != "") && (member.MembershipType != "" && member.ActiveStatus != "") && member.EnrolledClasses != "")
            {
                

                string path = control.GetFilePath();
                if (!File.Exists(path))
                    File.Create(path).Close();

                string[] lines = File.ReadAllLines(path);

                using (StreamWriter Members = new StreamWriter(path, true))//using closes the file,and checks if the file exists
                {


                    bool idExists = lines.Any(line => line.StartsWith($"Id:{member.MemberId}")); //  Check if any line starts with the member ID followed by a comma
                   
                    if (idExists)
                    {
                        MessageBox.Show("Id already exists!", "Failed",
                           MessageBoxButtons.OK, MessageBoxIcon.Error);
                        empty = [];
                    }


                    else
                    {
                        empty = [];
                        Members.WriteLine(member.ToString());
                        MessageBox.Show("Member added successfully!", "Success",
                               MessageBoxButtons.OK, MessageBoxIcon.Information);
                        string Enrolledclasses = @"C:\Users\USER\source\repos\GymManagment";
                        string Classes = Path.Combine(Enrolledclasses, "EnrolledClasses.txt");
                        if (!File.Exists(Classes))
                            File.Create(Classes).Close();
                        using (StreamWriter classes = new StreamWriter(Classes, true))
                        {
                            classes.WriteLine($"Id:{member.MemberId},Status:{member.ActiveStatus},EnrolledClasses:{member.EnrolledClasses}");
                        }
                        ResetButton_Click(sender, e);
                    }

                    


                }
              

            }
        }







        private void ResetButton_Click(object sender, EventArgs e)
        {

            control.Reset(IdBox, NameBox, MembershipBox, StatusBox, EnrolledClassesBox);


        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Main main = new Main();
            main.Show();
        }

        private void button1_Click(object sender, EventArgs e)//for remove
        {
            control.RemoveMember(control.GetFilePath(), member.MemberId);
            MessageBox.Show("Member removed successfully!",
                "Success",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
            empty = [];
    
            
        }
    }
}
