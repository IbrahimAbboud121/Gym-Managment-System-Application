﻿namespace GymManagment
{
    partial class MembersMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MembersMenu));
            IdBox = new Krypton.Toolkit.KryptonTextBox();
            NameBox = new Krypton.Toolkit.KryptonTextBox();
            StatusBox = new Krypton.Toolkit.KryptonTextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            MembershipBox = new ComboBox();
            label4 = new Label();
            label5 = new Label();
            BackButton = new Button();
            AddButton = new Button();
            EnrolledClassesBox = new Krypton.Toolkit.KryptonTextBox();
            ResetButton = new Button();
            button1 = new Button();
            SuspendLayout();
            // 
            // IdBox
            // 
            IdBox.Location = new Point(285, 191);
            IdBox.Name = "IdBox";
            IdBox.Size = new Size(96, 31);
            IdBox.TabIndex = 0;
            IdBox.TextChanged += IdBox_TextChanged;
            // 
            // NameBox
            // 
            NameBox.Location = new Point(474, 191);
            NameBox.Name = "NameBox";
            NameBox.Size = new Size(96, 31);
            NameBox.TabIndex = 1;
            // 
            // StatusBox
            // 
            StatusBox.Location = new Point(285, 338);
            StatusBox.Name = "StatusBox";
            StatusBox.Size = new Size(96, 31);
            StatusBox.TabIndex = 4;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(285, 163);
            label1.Name = "label1";
            label1.Size = new Size(97, 25);
            label1.TabIndex = 6;
            label1.Text = "MemberID";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(474, 163);
            label2.Name = "label2";
            label2.Size = new Size(59, 25);
            label2.TabIndex = 7;
            label2.Text = "Name";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(651, 163);
            label3.Name = "label3";
            label3.Size = new Size(154, 25);
            label3.TabIndex = 8;
            label3.Text = " MembershipType";
            // 
            // MembershipBox
            // 
            MembershipBox.FormattingEnabled = true;
            MembershipBox.Items.AddRange(new object[] { "Monthly", "Yearly" });
            MembershipBox.Location = new Point(651, 191);
            MembershipBox.Name = "MembershipBox";
            MembershipBox.Size = new Size(96, 33);
            MembershipBox.TabIndex = 9;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(285, 310);
            label4.Name = "label4";
            label4.Size = new Size(108, 25);
            label4.TabIndex = 10;
            label4.Text = "ActiveStatus";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(474, 310);
            label5.Name = "label5";
            label5.Size = new Size(133, 25);
            label5.TabIndex = 11;
            label5.Text = "EnrolledClasses";
            // 
            // BackButton
            // 
            BackButton.Location = new Point(348, 436);
            BackButton.Name = "BackButton";
            BackButton.Size = new Size(96, 31);
            BackButton.TabIndex = 12;
            BackButton.Text = "Back";
            BackButton.UseVisualStyleBackColor = true;
            BackButton.Click += BackButton_Click;
            // 
            // AddButton
            // 
            AddButton.Location = new Point(696, 338);
            AddButton.Name = "AddButton";
            AddButton.Size = new Size(96, 31);
            AddButton.TabIndex = 17;
            AddButton.Text = "Add";
            AddButton.UseVisualStyleBackColor = true;
            AddButton.Click += AddButton_Click;
            // 
            // EnrolledClassesBox
            // 
            EnrolledClassesBox.Location = new Point(474, 338);
            EnrolledClassesBox.Multiline = true;
            EnrolledClassesBox.Name = "EnrolledClassesBox";
            EnrolledClassesBox.ScrollBars = ScrollBars.Vertical;
            EnrolledClassesBox.Size = new Size(149, 46);
            EnrolledClassesBox.TabIndex = 19;
            // 
            // ResetButton
            // 
            ResetButton.Location = new Point(511, 436);
            ResetButton.Name = "ResetButton";
            ResetButton.Size = new Size(96, 31);
            ResetButton.TabIndex = 20;
            ResetButton.Text = "Reset";
            ResetButton.UseVisualStyleBackColor = true;
            ResetButton.Click += ResetButton_Click;
            // 
            // button1
            // 
            button1.Location = new Point(669, 436);
            button1.Name = "button1";
            button1.Size = new Size(96, 31);
            button1.TabIndex = 21;
            button1.Text = "Remove";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // MembersMenu
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.None;
            ClientSize = new Size(1042, 597);
            Controls.Add(button1);
            Controls.Add(ResetButton);
            Controls.Add(EnrolledClassesBox);
            Controls.Add(AddButton);
            Controls.Add(BackButton);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(MembershipBox);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(StatusBox);
            Controls.Add(NameBox);
            Controls.Add(IdBox);
            Name = "MembersMenu";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "MembersMenu";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Krypton.Toolkit.KryptonTextBox IdBox;
        private Krypton.Toolkit.KryptonTextBox NameBox;
        private Krypton.Toolkit.KryptonTextBox StatusBox;
        private Label label1;
        private Label label2;
        private Label label3;
        private ComboBox MembershipBox;
        private Label label4;
        private Label label5;
        private Button BackButton;
        private Button AddButton;
        private Krypton.Toolkit.KryptonTextBox EnrolledClassesBox;
        private Button ResetButton;
        private Button button1;
    }
}