﻿namespace GymManagment
{
    partial class Login
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login));
            emailbox = new TextBox();
            passbox = new TextBox();
            pictureBox1 = new PictureBox();
            pictureBox2 = new PictureBox();
            reset = new Button();
            loginbutton = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // emailbox
            // 
            emailbox.Font = new Font("Century Gothic", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            emailbox.Location = new Point(230, 335);
            emailbox.Name = "emailbox";
            emailbox.Size = new Size(187, 34);
            emailbox.TabIndex = 0;
            emailbox.TextChanged += textBox1_TextChanged;
            // 
            // passbox
            // 
            passbox.Font = new Font("Century Gothic", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            passbox.Location = new Point(230, 422);
            passbox.Name = "passbox";
            passbox.Size = new Size(187, 34);
            passbox.TabIndex = 1;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.White;
            pictureBox1.BackgroundImage = (Image)resources.GetObject("pictureBox1.BackgroundImage");
            pictureBox1.Location = new Point(419, 335);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(38, 34);
            pictureBox1.TabIndex = 4;
            pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.BackgroundImage = (Image)resources.GetObject("pictureBox2.BackgroundImage");
            pictureBox2.Location = new Point(419, 422);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(38, 34);
            pictureBox2.TabIndex = 5;
            pictureBox2.TabStop = false;
            // 
            // reset
            // 
            reset.Location = new Point(354, 515);
            reset.Name = "reset";
            reset.Size = new Size(83, 34);
            reset.TabIndex = 7;
            reset.Text = "Reset";
            reset.UseVisualStyleBackColor = true;
            reset.Click += reset_Click;
            // 
            // loginbutton
            // 
            loginbutton.Location = new Point(244, 515);
            loginbutton.Name = "loginbutton";
            loginbutton.Size = new Size(83, 34);
            loginbutton.TabIndex = 8;
            loginbutton.Text = "Login";
            loginbutton.UseVisualStyleBackColor = true;
            loginbutton.Click += loginbutton_Click;
            // 
            // Login
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(706, 690);
            Controls.Add(loginbutton);
            Controls.Add(reset);
            Controls.Add(pictureBox2);
            Controls.Add(pictureBox1);
            Controls.Add(passbox);
            Controls.Add(emailbox);
            Name = "Login";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Login";
            Load += Login_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox emailbox;
        private TextBox passbox;
        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private Button login;
        private Button reset;
        private Button loginbutton;
    }
}
