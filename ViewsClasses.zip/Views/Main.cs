﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GymManagment
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
            this.Font = new Font("Microsoft Sans Serif", 14, FontStyle.Regular);
        }

        private void Main_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            MembersMenu member = new MembersMenu();
            this.Hide();
            member.Show();
            
        }

        private void TrainersButton_Click(object sender, EventArgs e)
        {
            TrainersMenu trainer = new TrainersMenu();
            this.Hide();
            trainer.Show();
        }

        private void ClassSessionsButton_Click(object sender, EventArgs e)
        {
            ClassSessionsMenu sessions = new ClassSessionsMenu();
            this.Hide();
            sessions.Show();

        }
    }
}
