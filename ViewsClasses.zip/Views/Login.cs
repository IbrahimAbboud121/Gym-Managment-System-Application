using GymManagment.Controller;
using GymManagment.Model;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using GymManagment.DataBase;

namespace GymManagment
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        //creating instances
        LoginController verifie = new LoginController();
        DataBaseClass database = DataBaseClass.GetInstance();



        private void loginbutton_Click(object sender, EventArgs e)
        {

            //creating a user 
            LoginModel user = new LoginModel(emailbox.Text, passbox.Text);

            //using the functions to check the email and pass
            bool emailisvalid = verifie.VerifieEmail(user.Email);
            bool passisvalid = verifie.VerifiePassword(user.Password);
            if (!emailisvalid)
            {
                MessageBox.Show("Invalid email format!\n\n" +
                             $"Entered: {user.Email}\n\n" +
                             "Valid format: name@domain.com",
                             "Invalid Email",
                             MessageBoxButtons.OK,//OK means after the error message is displayed=>
                                                  //i can only press ok to exist the error message
                             MessageBoxIcon.Error);
            }
            if (!passisvalid && emailisvalid)
            {
                MessageBox.Show("Password should not be empty and should be more than 8 characters",
             "Validation Error",
             MessageBoxButtons.OK,
             MessageBoxIcon.Error);
            }


            if (emailisvalid && passisvalid)
            {
                try
                {
                    using (Microsoft.Data.SqlClient.SqlConnection con = database.GetConnection())//using using() is more safe,always closes the con
                    {
                        con.Open();

                        // Check if email and password exist in Workers table
                        string query = "SELECT COUNT(*) FROM Workers WHERE Email = @Email AND Password = @Password";

                        using (Microsoft.Data.SqlClient.SqlCommand cmd = new Microsoft.Data.SqlClient.SqlCommand(query, con))
                        {
                            cmd.Parameters.AddWithValue("@Email", emailbox.Text);//cmd is like a list of dictionary,my order
                            cmd.Parameters.AddWithValue("@Password", passbox.Text);

                            int result = (int)cmd.ExecuteScalar();

                            if (result > 0)
                            {
                                MessageBox.Show("Login successful! Welcome to Gym Management System.",
                                                "Success",
                                                MessageBoxButtons.OK,
                                                MessageBoxIcon.Information);

                                // OPEN MAIN FORM AND HIDE LOGIN
                                Main mainForm = new Main();
                                this.Hide();  // Hide the login form
                                mainForm.Show();

                            }
                            else
                            {
                                MessageBox.Show("Invalid email or password! Please check your credentials.",
                                                "Login Failed",
                                                MessageBoxButtons.OK,
                                                MessageBoxIcon.Error);
                            }
                        }


                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void reset_Click(object sender, EventArgs e)
        {
            emailbox.Text = "";
            passbox.Text = "";
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }
    }
}