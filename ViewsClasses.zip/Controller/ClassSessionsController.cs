﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace GymManagment.Controller
{
    public class ClassSessionsController
    {
        static readonly string filepath = @"C:\Users\USER\source\repos\GymManagment";
        static readonly string path = filepath;
        public string GetFilePath()
        {
            return Path.Combine(path, "ClassSession.txt");
        }



        public string[] IsUserLegal(string id)
        {
            
            string  Enrolledclasses = @"C:\Users\USER\source\repos\GymManagment";
            string Classes = Path.Combine(Enrolledclasses, "EnrolledClasses.txt");

            List<string> line = File.ReadAllLines(Classes).ToList();
            string memberline = "";
            int memberindex = -1;
            if (File.Exists(Classes))
            {
                for (int j = 0; j < line.Count; j++)
                {
                    if (id.Length==4 &&  line[j].Contains(id))
                    {
                        memberindex = j;
                        break;
                    }
                }

                if (memberindex == -1)
                {
                    
                    return null;
                }

                else
                {
                    memberline = line[memberindex];
                    memberindex++;


                    while (memberindex < line.Count && !line[memberindex].StartsWith("Id:"))
                    {
                        memberline = memberline + line[memberindex];
                        memberindex++;
                    }


                    string[] WeFoundTheMember = memberline.Split(',', ':');



                    int i = 5; // index of after enrolled classes
                    string cls = "";

                    while (i < WeFoundTheMember.Length)
                    {
                        cls += WeFoundTheMember[i] + ",";
                        i++;
                    }
                    if (cls.EndsWith(","))
                        cls = cls.Substring(0, cls.Length - 1);

                    return [WeFoundTheMember[1], WeFoundTheMember[3], cls];
                }
            }
            else
                return null;
    }

        




}
    }
