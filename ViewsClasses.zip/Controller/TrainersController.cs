﻿using Krypton.Toolkit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GymManagment.Controller
{
    public class TrainersController
    {
        static readonly string filepath = @"C:\Users\USER\source\repos\GymManagment";
        static readonly string path = filepath;
        public string GetFilePath()
        {
            return Path.Combine(path, "trainers.txt");
        }


        public void Reset(KryptonTextBox id, KryptonTextBox name,TextBox specialization,TextBox classes)
        {
            id.Clear();
            name.Clear();
            specialization.Clear();
            classes.Clear();



        }

        public void RemoveTrainer(string path, string Id)
        {
            if (File.Exists(path))
            {
                List<string> lines = File.ReadAllLines(path).ToList();

                // 1. Find the EXACT member line
                int memberIndex = -1;
                for (int i = 0; i < lines.Count; i++)
                {
                    // Be specific: line must start with "Id:" AND contain the ID
                    if (lines[i].StartsWith("Id:") && lines[i].Contains(Id))
                    {
                        memberIndex = i;
                        break;  // IDs are unique, stop at first match
                    }
                }

                if (memberIndex == -1)
                {
                    MessageBox.Show("Member not found!", "Not fount", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // 2. Remove the member's ID line FIRST using RemoveAt
                lines.RemoveAt(memberIndex);

                // 3. Remove all extra data lines for this member
                // Start from the SAME index (list shifted after removal)
                while (memberIndex < lines.Count && !lines[memberIndex].StartsWith("Id:"))
                {
                    lines.RemoveAt(memberIndex);
                    // Don't increment memberIndex - we keep removing from same position
                }

                File.WriteAllLines(path, lines);

            }
        }
    }
}
