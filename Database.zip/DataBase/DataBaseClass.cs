﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GymManagment.DataBase
{
   //using singleton
    public sealed class DataBaseClass
    {
        private readonly  string _connection =@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=GymManagement;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False";
        private static DataBaseClass _instance;

        private DataBaseClass() { }

        public Microsoft.Data.SqlClient.SqlConnection GetConnection()
        {
            return new Microsoft.Data.SqlClient.SqlConnection(_connection);
        }
        public static DataBaseClass GetInstance()
        {
            if(_instance==null)
            _instance = new DataBaseClass();

          return _instance;
        }

    }
}
