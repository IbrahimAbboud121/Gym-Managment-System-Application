﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GymManagment.Model
{
    public class MemberModel
    {
        public string MemberId { get; set; }
        public string Name { get; set; }
        public string MembershipType { get; set; }
        public string ActiveStatus { get; set; }
        public string EnrolledClasses { get; set; }
        public MemberModel(string id,string name,string type,string status,string enrolledclasses)
        {
            MemberId = id;
            Name = name;
            MembershipType = type;
            ActiveStatus = status;
            EnrolledClasses = enrolledclasses;

        }
        public override string ToString()
        {
            return $"Id:{MemberId} , Name:{Name} , MembershipType:{MembershipType} , ActiveStatus:{ActiveStatus} , EnrolledClasses:{EnrolledClasses}";
        }

    }
}
