﻿using System;
using GymManagment.Controller;

namespace GymManagment.Model
{
    

    public class ClassSessionsModel
    {
        public string SessionId { get; set; }
        public string Name { get; set; }
        public TrainersModel Trainer { get; set; }
        public string ScheduleTime { get; set; }
        public string MaxSlots { get; set; }  
        public string BookedMembers { get; set; }

        public ClassSessionsModel(string id, string name, TrainersModel trainer, string time,string slots,string bookedmembers)
        {
            SessionId = id;
            Name = name;
            Trainer = trainer;
            ScheduleTime = time;
              MaxSlots = slots;
            BookedMembers = bookedmembers;



        }

        public override string ToString()
        {
            return $"SessionName:{Name},Id:{SessionId},Time:{ScheduleTime}";
        }





       
        
    }
}