﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace GymManagment.Controller
{
    public class LoginController
    {
        //function to verifie email
        public bool VerifieEmail(string Email)
        {
            string pattern = @"^\w+@gmail\.com$"; // we have \. because . is a symbol and /w means [a-zA-Z0-9_]
            if (!Regex.IsMatch(Email, pattern))
                return false;
            else
                return true;
            
        }

        
        //function to check password
        public bool VerifiePassword(string pass)
        {
            if (pass == "" || pass.Length < 8)
             return false;
            
            else
                return true;
        }

        //function to check if the email and pass exists in the data base

    }
}
